// export const value = (param) => {
// 	console.log('Getter', param);
// };