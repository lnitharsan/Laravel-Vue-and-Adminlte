
// export const SET_EVENTS = (state, payload) => {
//     state.events = payload;
// };