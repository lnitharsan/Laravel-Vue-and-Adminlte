import { store } from './../store';

// export const getInitClient = (context, payload) => {
//   return api.get('init/client')
//     .then((response) => {
//       context.commit('SET_CLIENT', response.data.result);
//     })
//     .catch((error) => {
//       context.dispatch('errorModal', { title:'Init Client Failed', message:error.body.errormessage });
//     });
// };