export const client_id = Laravel.passport.client_id;
export const client_secret = Laravel.passport.client_secret;