<template>
    <aside class="control-sidebar control-sidebar-dark">
        <!-- Control sidebar content goes here -->
    </aside>
</template>

<script>
export default {
  computed: {

  },
  created() {

  },
  methods: {

  }
};
</script>
