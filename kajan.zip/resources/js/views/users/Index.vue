<template>
	<div>
		<section class="content-header">
			<h1>Users</h1>
		</section>

		<section class="content"></section>
	</div>
</template>