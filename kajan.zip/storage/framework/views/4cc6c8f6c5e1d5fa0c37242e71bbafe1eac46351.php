<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>

    
    <script>
        window.Laravel = <?php echo json_encode([
            'csrfToken' => csrf_token(),
            'baseUrl' => url('/'),
            'appName' => config('app.name'),
            'passport' => config('userdata.passport'),
            'lang' => [
                'general' => __('general'),
                'auth' => __('auth'),
                'message' => __('message'),
                'pagination' => __('pagination'),
                'passwords' => __('passwords'),
                'validation' => __('validation'),
            ],
        ]); ?>
    </script>

    <!-- Scripts -->
    <script src="<?php echo e(mix('js/app.js')); ?>" defer></script>

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">

    <!-- Styles -->
    <link href="<?php echo e(mix('css/app.css')); ?>" rel="stylesheet">
</head>
<body>
<div id="userApp">
    <div id="loader" ref="loader">
        <div class="dot"></div>
        <div class="dot"></div>
        <div class="dot"></div>
        <div class="dot"></div>
        <div class="dot"></div>
        <div class="dot"></div>
        <div class="dot"></div>
        <div class="dot"></div>
        <div class="lading"></div>
    </div>
    <router-view></router-view>
</div>
</body>
</html>
<?php /**PATH C:\Apps\PHP\kajan\resources\views/index.blade.php ENDPATH**/ ?>